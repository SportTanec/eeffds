#!/bin/bash
source ./venv/bin/activate
echo 'start threading check seed/private key'
python3 code/threading_main.py
echo 'press enter'
read
