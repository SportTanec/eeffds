#!/bin/bash
source ./venv/bin/activate
echo 'start parse log file'
python3 code/parse_log.py

echo 'press enter'
read
