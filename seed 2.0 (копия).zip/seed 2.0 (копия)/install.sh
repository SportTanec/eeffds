#!/bin/bash
echo 'start install'
echo 'create vurtual environment'
python3 -m venv venv
source ./venv/bin/activate
echo 'download requirements'
pip install -r ./requirements.txt

echo 'ready to check seeds'
echo 'press enter'

read
