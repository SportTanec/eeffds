#!/bin/bash
source ./venv/bin/activate
echo 'start spliter file'
python3 code/spliter.py

echo 'press enter'
read
