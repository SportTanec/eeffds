from config import *

import os

def split_files(input_dir, output_dir, chunk_size):
    file_count = 1
    elements = []
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for filename in os.listdir(input_dir):
        with open(os.path.join(input_dir, filename), 'rb') as input_file:
            for line in input_file:
                try:
                    line = line.strip().decode('utf-8')  # Попытка декодирования строки как UTF-8
                    elements.append(line) 
                    if len(elements) == chunk_size:
                        output_file = os.path.join(output_dir, f'after_split_{file_count}.txt')
                        with open(output_file, 'w') as file:
                            file.write('\n'.join(elements))
                            print(f'Файл after_split_{file_count}.txt создан')
                        file_count += 1
                        elements = [] 
                except UnicodeDecodeError:
                    print(f'Ошибка кодировки в строке файла: {filename}\n{len(elements)+(file_count*chunk_size)}-ая строка будет пропущена.')
    
    if len(elements) > 0:
        output_file = os.path.join(output_dir, f'after_split_{file_count}.txt')
        with open(output_file, 'w') as file:
            file.write('\n'.join(elements))
            print(f'Файл after_split_{file_count}.txt создан')
    
    print('Обработка файлов завершена.')

input_folder = ROOT + './pre_for_check'
output_folder = ROOT + './for_check'
chunk_size = CFG['chunk_size']#100_000


split_files(input_folder, output_folder, chunk_size)
