import json, os, sys

ROOT = ''
#print(ROOT)

with open(f'{ROOT}config.json', 'rb') as json_cfg:
    pre_cfg = json.load(json_cfg)

K_MAX = pre_cfg['K_MAX']

T = pre_cfg['T']

T_ST = pre_cfg['T_ST']


IDS = pre_cfg['IDS']

CFG = pre_cfg['CFG']

with open(f'{ROOT}proxy.txt', 'r+') as file:
    PROXY = file.read().split('\n')

with open(f'{ROOT}bep39.txt', 'r+') as file:
    BEP39 = file.read().split('\n')

with open(f'{ROOT}anty_public.txt', 'r+') as file:
    ANTY = file.read().split('\n') if CFG['ап'] else []