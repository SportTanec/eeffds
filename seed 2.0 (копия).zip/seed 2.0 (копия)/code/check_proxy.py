import requests, time, os

bob = {
    'True' : 'Валид',
    'False' : 'Неалид'
}
def check_proxy(proxy):
    #try:
        #http://B2FEaj61:9DZTE1tp@176.103.95.115:64202
        try:
            proxy_ = f"http://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}

        except:
            proxy_ = f"http://{proxy.split(':')[0]}:{proxy.split(':')[1]}"
            proxies = {"http": proxy_, "https": proxy_}
        
        try:
            response = requests.get('http://ya.ru', proxies=proxies)        
        
        except:
            return False
        
        
        # Сделать запрос через прокси-сервер
        if response.status_code == 200:
            return True
        else:
            return False
    #except:
        return False

with open('proxy.txt', 'r+', encoding = 'utf-8') as f:
    PROXY = f.read().split('\n')
    
for proxy in PROXY:
    tt = f"{check_proxy(proxy)}"
    print(proxy, bob[f'{tt}'])
