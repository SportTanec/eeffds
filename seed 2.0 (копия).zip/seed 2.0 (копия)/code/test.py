from function import *

seed = 'display settle jewel process join educate when learn icon card sand direct'
print(get(seed, 'ETH'))
#print(check_process(1, seed))