import os, re
from function import *
from tqdm import tqdm

for root, dirs, files in os.walk("./logs/"):  
    for filename in tqdm(files):
        try:
            with open(f"{root}/{filename}", 'r') as f:
                st = f.readline()
                while st != '':
                    res = find_data(st)
                    if res != '' and (len(res) == 64 or len(res.split(' ')) in [12, 18, 24]):
                        print(res)
                        with open(f"{ROOT}parse_res.txt", 'a') as f1:
                            f1.write(f'{res}\n')
                
                    st = f.readline()
                    
        except:
            ...
        finally:
            os.remove(f"{root}/{filename}")
            print('Файл {filename} обработан')

with open(f'{ROOT}parse_res.txt', 'r+') as f:
    all_res = list(set(f.readlines()))

ress = ''
with open(f'{ROOT}parse_res.txt', 'w') as f:
    for res in all_res:
        ress += f'{res}'

    f.write(ress)
    
print('Конец парса')