import qrcode, time, os

def create_qr_code(data, folder_path, file_name):
    # Создание экземпляра QR-кода
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(data)
    qr.make(fit=True)

    # Генерация изображения QR-кода
    qr_image = qr.make_image(fill="black", back_color="white")

    # Создание пути к файлу
    file_path = os.path.join(folder_path, file_name)

    # Сохранение изображения QR-кода
    qr_image.save(file_path)

with open('super_res.txt', 'r+') as file:
    seeds = file.read().split('\n')

for i, data in enumerate(seeds):
    # Генерация имени файла на основе индекса строки
    if data != '':
        file_name = f"{data.split(' | ')[1][1:-2]}.png"

        # Создание QR-кода и сохранение его в папке
        create_qr_code(data.split(' | ')[0], './qr_res', file_name)

