#!/bin/bash
source ./venv/bin/activate
echo 'start multiprocessing check seed/private key'
python3 code/multiprocessing_main.py
echo 'press enter'
read
