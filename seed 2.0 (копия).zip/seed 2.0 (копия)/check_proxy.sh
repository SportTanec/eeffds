#!/bin/bash
source ./venv/bin/activate
echo 'start check proxy file'
python3 code/check_proxy.py

echo 'press enter'
read
